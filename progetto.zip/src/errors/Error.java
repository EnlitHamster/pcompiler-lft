package errors;

import java.lang.Exception;

public class Error extends Exception {

	public Error(String msg) {
		super(msg);
	}

}
